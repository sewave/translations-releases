Yazzie (Mega Drive)
Traducción al Español v1.0 (14/01/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
yazzie.bin
MD5: ae5c6b88c02b3e0c28fa1ee57b1ad88b
SHA1: 5d0b94db54ecb60334b7de605082613f8509b41b
CRC32: 93d5ad8a
655360 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --