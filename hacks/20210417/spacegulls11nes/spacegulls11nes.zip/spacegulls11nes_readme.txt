Spacegulls 1.1 (NES)
Traducción al Español v1.0 (17/04/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Spacegulls-1.1.nes
MD5: 975d4fe8693cd9941b65aa8de7f6d5bd
SHA1: 14a8b1d66c126698148972ffa962abd73c24c561
CRC32: 539f87d4
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --