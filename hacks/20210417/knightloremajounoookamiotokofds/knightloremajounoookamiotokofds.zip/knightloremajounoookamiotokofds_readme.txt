Knight Lore - Majou no Ookami Otoko (Famicom Disk System)
Traducción al Español v1.0 (17/04/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Knight Lore - Majou no Ookami Otoko (Japan).fds
MD5: 43c994c5c351dcbe0d073a4aa0d7fa5c
SHA1: 4048dfcf6bfb13e8fde12558c63c3cfa4573346b
CRC32: c07a8b04
131016 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --