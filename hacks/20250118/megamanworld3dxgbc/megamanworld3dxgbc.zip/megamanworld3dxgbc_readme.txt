Mega Man World 3 DX (Game Boy Color)
Traducción al Español v1.0 (18/01/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de marc_max.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mega Man III (USA).gb
MD5: 4c614f884a07872f12056ad1a421e1f9
SHA1: 57347305ab297daa4332564623c4a098e6dbb1a3
CRC32: 5175d761
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --