Vigilante (Master System)
Traducción al Español v2.0 (13/02/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Añadidos acentos
-Revisión de script
-Traducido STAGE

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Vigilante (USA, Europe, Brazil).sms
MD5: 6deabfc15d9aeb4c8ed1b641fb950de5
SHA1: 0dc37f1104508c2c0e2593b10dffc3f268ae8ff9
CRC32: dfb0b161
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --