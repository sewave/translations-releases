Ultimate Air Combat (NES)
Traducción al Español v1.0 (31/01/2026)
(C) 2026 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ultimate Air Combat (USA).nes
MD5: 39db9f419c23b9b4cd458f453abe5f59
SHA1: 17b38017afba646f75eca9f328c37dfc00fa0083
CRC32: 83590206
524304 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --