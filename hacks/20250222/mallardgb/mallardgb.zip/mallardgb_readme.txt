Sam Mallard - The Case of the Missing Swan (Game Boy)
Traducción al Español v1.0 (22/02/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sam Mallard - The Case of the Missing Swan (World) (SGB Enhanced) (Aftermarket) (Unl).gb
MD5: 83fc53defeb7b05ac619c9918797ee83
SHA1: 0132f0311d8478d4f45b3b8e2728698570091d69
CRC32: 994a2edd
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --