Batman Returns (Super Nintendo)
Traducción al Español v1.0 (22/05/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

Sin traducir en la intro:
HOWEVER THERE IS A NEW PLAYER
IN TOWN.AN ADVERSARY THAT
CREATES CHAOS IN GOTHAM CITY.

SIN EMBARGO HAY UN NUEVO JUGADOR
EN LA CIUDAD.UN ADVERSARIO QUE
CREA CAOS EN GOTHAM CITY.

Con Catwoman:
GOTTA GO.GIRL TALK!
TENGO QUE IRME.¡CHARLA DE CHICAS!

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Batman Returns (USA).sfc
MD5: 5ef8e1f3e88c86f149838c569a0c0328
SHA1: 087f414d51c999e25ced561fe21503c559d8050f
CRC32: e87dfdf6
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --