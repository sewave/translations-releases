Don Doko Don 2
Traducci�n al Espa�ol v1.0 (20/02/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Don Doko Don 2
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Don Doko Don 2
-----------------
Curioso plataformas de Taito de un enano que pega martillazos.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
Se han a�adido caractere especiales.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Don Doko Don 2 (J).nes
393.232	bytes
CRC32: b04ece9e
MD5: 116d9a34e5c5fc9a0912c1ec11ace157
SHA1: d1f3a33cabdb2f075ecc5b60820241fe94216ba9

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --