Teenage Mutant Ninja Turtles - Tournament Fighters (NES)
Traducción al Español v2.1 (08/01/2026)
(C) 2026 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Traducidos créditos
-Añadidos caracteres españoles
-Guion retraducido
-Mejorada traducción de opciones
-Traducidos gráficos de batalla, FIGHT, WIN, etc.
-Traducido SCORE
-Traducida etapa de bonos
-Mejorada pantalla de elección de fase

V2.1:
-Adaptados nombres de escenarios para evitar cambio de color en texto

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Teenage Mutant Ninja Turtles - Tournament Fighters (USA).nes
MD5: 1b04aff093c89068fe1c86d8c061ee79
SHA1: 85873ccfafe233309bacfb8d5d30a3721ee4508f
CRC32: 3d2face7
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --